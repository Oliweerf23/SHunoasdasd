"use client";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";

export function ThemeToggle(){
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";
  return (
    <button
      aria-label="Byt tema"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className={`px-3 py-1.5 rounded-xl text-sm inline-flex items-center gap-2 ${isDark ? "border border-slate-700 text-slate-200 hover:bg-slate-800/60" : "border border-slate-300 text-slate-700 hover:bg-slate-100"}`}
    >
      {isDark ? <Sun className="h-4 w-4"/> : <Moon className="h-4 w-4"/>}
      {isDark ? "Light" : "Dark"}
    </button>
  );
}
