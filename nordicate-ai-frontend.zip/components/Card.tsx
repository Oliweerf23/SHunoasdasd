import React from "react";

export function Card({ children, className = "", theme = "dark" }:{ children: React.ReactNode, className?: string, theme?: "light"|"dark" }) {
  const base = theme === "dark" ? "rounded-2xl border border-slate-800 bg-slate-900/60 shadow-sm" : "rounded-2xl border border-slate-200 bg-white shadow-sm";
  return <div className={`${base} ${className}`}>{children}</div>;
}
