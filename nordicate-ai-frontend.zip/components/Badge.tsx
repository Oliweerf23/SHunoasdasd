import React from "react";

export function Badge({ children, tone = "neutral", className = "", theme = "dark" }:{ children: React.ReactNode, tone?: "neutral"|"good"|"bad", className?: string, theme?: "light"|"dark" }) {
  const map:any = {
    neutral: theme === "dark" ? "bg-slate-800 text-slate-100 border-slate-700" : "bg-slate-100 text-slate-700 border-slate-200",
    good: theme === "dark" ? "bg-emerald-900/40 text-emerald-200 border-emerald-700/50" : "bg-emerald-50 text-emerald-700 border-emerald-200",
    bad: theme === "dark" ? "bg-rose-900/40 text-rose-200 border-rose-700/50" : "bg-rose-50 text-rose-700 border-rose-200",
  };
  return <span className={`px-2 py-1 text-xs rounded-full border ${map[tone]} ${className}`}>{children}</span>;
}
