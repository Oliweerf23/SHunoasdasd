"use client";

import { useEffect, useState } from "react";
import { ArrowUpRight, ArrowDownRight, Bot, Gauge, LineChart, Settings, Goal, Inbox, Bell, Send, Link2, Plug, Database, CheckCircle2, AlertCircle } from "lucide-react";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { ThemeToggle } from "@/components/ThemeToggle";

type KPIItem = { key:string; label:string; value:number; delta:number; up:boolean; explain:string };
type Insight = { id:string|number; tag:string; category:string; severity:"good"|"bad"|"neutral"; summary:string; evidence:string; actions:string[] };

export default function Dashboard(){
  const [theme, setTheme] = useState<"light"|"dark">("dark"); // only for Badge/Card tone hints
  const [chat, setChat] = useState("");
  const [kpis, setKpis] = useState<KPIItem[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);

  useEffect(() => {
    // fetch mock data
    fetch("/api/kpis").then(r=>r.json()).then(d=>{
      // decorate for UI
      const mapped:KPIItem[] = d.items.map((it:any)=>{
        const up = it.delta >= 0;
        const explain = it.key === "cr" ? "Andel besökare som blev kund/lead" : ({
          visits: "Hur många besök din sajt haft senaste veckan.",
          people: "Uppskattat antal unika personer.",
          leads: "Antal skickade formulär eller ordrar."
        } as any)[it.key] || "";
        return { ...it, up, explain };
      });
      setKpis(mapped);
    });
    fetch("/api/insights").then(r=>r.json()).then(d=> setInsights(d.insights || []));
  }, []);

  const isDark = true; // UI palette handled by global theme; here only affects class toggles

  return (
    <div className={isDark ? "min-h-screen bg-[#0f172a] text-slate-200" : "min-h-screen bg-white text-slate-900"}>
      {/* Topbar */}
      <div className={isDark ? "sticky top-0 z-40 border-b border-slate-800/80 backdrop-blur bg-[#0f172a]/80" : "sticky top-0 z-40 border-b border-slate-200 bg-white/80"}>
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-[#123a63] to-[#35a5db] grid place-items-center font-bold">N</div>
            <div className={"text-sm " + (isDark ? "text-slate-400" : "text-slate-600")}>Nordicate AI</div>
          </div>
          <div className="flex items-center gap-3">
            <Badge theme={isDark ? "dark":"light"}>GA4: my-site.com</Badge>
            <Badge theme={isDark ? "dark":"light"}>Timezone: Europe/Stockholm</Badge>
            <button className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm inline-flex items-center gap-2">
              <Plug className="h-4 w-4"/> Koppla ny property
            </button>
            <ThemeToggle/>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6 grid grid-cols-12 gap-4">
        {/* Sidebar */}
        <aside className="col-span-12 md:col-span-3 lg:col-span-2">
          <Card theme={isDark ? "dark":"light"}>
            <nav className="p-3 space-y-1 text-sm">
              <NavItem theme={isDark ? "dark":"light"} icon={<Gauge className="h-4 w-4"/>} label="Hem" active/>
              <NavItem theme={isDark ? "dark":"light"} icon={<LineChart className="h-4 w-4"/>} label="Insikter"/>
              <NavItem theme={isDark ? "dark":"light"} icon={<Bot className="h-4 w-4"/>} label="Ställ en fråga"/>
              <NavItem theme={isDark ? "dark":"light"} icon={<Goal className="h-4 w-4"/>} label="Mål & resultat"/>
              <NavItem theme={isDark ? "dark":"light"} icon={<Inbox className="h-4 w-4"/>} label="Utskicken"/>
              <NavItem theme={isDark ? "dark":"light"} icon={<Settings className="h-4 w-4"/>} label="Inställningar"/>
            </nav>
          </Card>
          <Card className="mt-4" theme={isDark ? "dark":"light"}>
            <div className={"p-4 text-xs space-y-2 " + (isDark ? "text-slate-400" : "text-slate-600")}>
              <div className="flex items-center gap-2"><Database className="h-3.5 w-3.5"/> Snapshot: 2025‑08‑04 07:00</div>
              <div className="flex items-center gap-2"><Bell className="h-3.5 w-3.5"/> Larm: 1 kritiskt, 2 info</div>
              <div className="flex items-center gap-2"><Link2 className="h-3.5 w-3.5"/> Export: Webflow, Slack</div>
            </div>
          </Card>
        </aside>

        {/* Main */}
        <main className="col-span-12 md:col-span-9 lg:col-span-10 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h1 className={"text-lg font-semibold " + (isDark ? "text-slate-100" : "text-slate-900")}>Överblick</h1>
            <div className={"text-xs " + (isDark ? "text-slate-400" : "text-slate-600")}>Senaste veckan vs veckan innan</div>
          </div>
          <div className={"text-[11px] " + (isDark ? "text-slate-400" : "text-slate-600")}>Grönt = bättre än förra veckan. Rött = sämre.</div>

          {/* KPI Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            {kpis.map((k) => (
              <Card key={k.key} theme={isDark ? "dark":"light"}>
                <div className="p-5">
                  <div className={"text-xs " + (isDark ? "text-slate-400" : "text-slate-600")}>{k.label}</div>
                  <div className={"mt-1 text-2xl font-semibold " + (isDark ? "text-slate-100" : "text-slate-900")}>
                    {k.key === "cr" ? `${(k.value * 100).toFixed(1)}%` : k.value.toLocaleString("sv-SE")}
                  </div>
                  <div className={"mt-1 text-[11px] " + (isDark ? "text-slate-400" : "text-slate-600")}>
                    {k.key === "cr" ? "(Exempel: 24 av 1 000)" : k.explain}
                  </div>
                  <div className={"mt-2 text-sm inline-flex items-center gap-1 " + (k.up ? (isDark ? "text-emerald-400" : "text-emerald-600") : (isDark ? "text-rose-400" : "text-rose-600"))}>
                    {k.up ? <ArrowUpRight className="h-4 w-4"/> : <ArrowDownRight className="h-4 w-4"/>}
                    {k.key === "cr" ? `${(k.delta * 100).toFixed(1)} p.p.` : `${Math.round(Math.abs(k.delta) * 100)}% WoW`}
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* What works / not */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card theme={isDark ? "dark":"light"}>
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2"> <CheckCircle2 className="h-4 w-4 text-emerald-500"/> <div className={"text-sm " + (isDark ? "text-slate-200" : "text-slate-800")}>Det här funkar</div></div>
                <p className="text-sm">Google går bättre än förra veckan. Fokusera på /tjänster/seo.</p>
              </div>
            </Card>
            <Card theme={isDark ? "dark":"light"}>
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2"> <AlertCircle className="h-4 w-4 text-rose-500"/> <div className={"text-sm " + (isDark ? "text-slate-200" : "text-slate-800")}>Det här funkar inte</div></div>
                <p className="text-sm">Prissidan tappar i mobil. Byt CTA och lätta bilden.</p>
              </div>
            </Card>
          </div>

          {/* Quick Wins */}
          <Card theme={isDark ? "dark":"light"}>
            <div className="p-5">
              <div className={"text-sm mb-2 " + (isDark ? "text-slate-300" : "text-slate-700")}>3 snabba vinster denna vecka</div>
              <ul className="grid md:grid-cols-3 gap-3">
                {["Lägg internlänk till /tjänster/seo.", "Byt CTA på prissidan till ‘Starta gratis’.", "Komprimera prissidans hero-bild till <120KB."].map((txt, i)=>(
                  <li key={i} className={(isDark ? "border-slate-800 bg-slate-950/40" : "border-slate-200 bg-white") + " p-3 rounded-xl border text-sm"}>
                    <div className="font-medium mb-1">{txt}</div>
                    <div className={(isDark ? "text-slate-400" : "text-slate-600") + " text-[11px]"}>Snabb effekt, låg insats.</div>
                    <div className="mt-2 text-[11px] opacity-70">Åtgärder kommer här.</div>
                  </li>
                ))}
              </ul>
            </div>
          </Card>

          {/* Trend placeholder */}
          <Card theme={isDark ? "dark":"light"}>
            <div className="p-5">
              <div className={"text-sm mb-2 " + (isDark ? "text-slate-300" : "text-slate-700")}>Trend (4 veckor)</div>
              <div className={(isDark ? "bg-slate-800/80 text-slate-500" : "bg-slate-100 text-slate-500") + " h-24 rounded-xl grid place-items-center text-xs"}>[Line chart placeholder]</div>
            </div>
          </Card>

          {/* Insights (top 3, with 'show more' stub) */}
          <Card theme={isDark ? "dark":"light"}>
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className={"text-sm " + (isDark ? "text-slate-300" : "text-slate-700")}>Insikter</div>
                <div className="text-xs opacity-70">Senaste veckan vs veckan innan</div>
              </div>
              <ul className="space-y-3">
                {insights.slice(0,3).map((ins) => (
                  <li key={ins.id} className={(isDark ? "border-slate-800 bg-slate-950/40" : "border-slate-200 bg-white") + " p-3 rounded-xl border"}>
                    <div className="flex items-center gap-2 text-xs mb-1">
                      <Badge tone={ins.severity === "bad" ? "bad" : ins.severity === "good" ? "good" : "neutral"} theme={isDark ? "dark":"light"}>{ins.category}</Badge>
                      <Badge theme={isDark ? "dark":"light"}>{ins.tag}</Badge>
                    </div>
                    <div className={(isDark ? "text-slate-100" : "text-slate-900") + " text-sm"}>{ins.summary}</div>
                    <ul className="mt-2 grid gap-2">
                      {ins.actions.map((a, i) => (
                        <li key={i} className={(isDark ? "text-slate-300" : "text-slate-700") + " text-xs list-disc ml-4"}>{a}</li>
                      ))}
                    </ul>
                    <details className="mt-2">
                      <summary className={(isDark ? "text-slate-400" : "text-slate-600") + " text-xs cursor-pointer"}>Varför?</summary>
                      <div className={(isDark ? "text-slate-300" : "text-slate-700") + " mt-1 text-xs"}>{ins.evidence}</div>
                    </details>
                  </li>
                ))}
              </ul>
              <button className="mt-3 text-xs underline opacity-80">Visa fler insikter</button>
            </div>
          </Card>

          {/* Ask */}
          <Card theme={isDark ? "dark":"light"}>
            <div className="p-5 h-full flex flex-col">
              <div className={(isDark ? "text-slate-300" : "text-slate-700") + " text-sm mb-2 flex items-center gap-2"}> <Bot className="h-4 w-4"/> Ställ en fråga</div>
              <div className={(isDark ? "border-slate-800 bg-slate-950/40 text-slate-400" : "border-slate-200 bg-white text-slate-600") + " flex-1 rounded-xl border p-3 text-sm"}>
                <p className="mb-2">Förslag på frågor:</p>
                <ul className="list-disc ml-4 space-y-1 text-sm">
                  <li>Vad gick bäst förra veckan?</li>
                  <li>Vad gick sämst?</li>
                  <li>Vad ska jag ändra först?</li>
                </ul>
              </div>
              <form className="mt-3 flex gap-2" onSubmit={(e) => e.preventDefault()}>
                <input
                  value={chat}
                  onChange={(e) => setChat(e.target.value)}
                  className={(isDark ? "bg-slate-950/60 border-slate-800 text-slate-200" : "bg-white border-slate-300 text-slate-900") + " flex-1 rounded-xl border px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-600"}
                  placeholder="Skriv med vanliga ord: Vad gick bäst? Vad ska jag ändra?"
                />
                <button className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm inline-flex items-center gap-1">
                  <Send className="h-4 w-4"/> Skicka
                </button>
              </form>
            </div>
          </Card>
        </main>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active = false, theme = "dark" }:{ icon:any; label:string; active?:boolean; theme?:"light"|"dark" }){
  const isDark = theme === "dark";
  return (
    <button className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl transition border text-left ${
      active
        ? (isDark ? "bg-blue-600/20 text-slate-100 border-blue-800/40" : "bg-blue-50 text-blue-900 border-blue-200")
        : (isDark ? "hover:bg-slate-800/60 text-slate-300 border-transparent" : "hover:bg-slate-100 text-slate-700 border-transparent")
    }`}>
      <span className="opacity-80">{icon}</span>
      <span className="text-sm">{label}</span>
    </button>
  );
}
