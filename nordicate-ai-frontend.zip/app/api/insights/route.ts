import { NextResponse } from "next/server";

export async function GET(){
  return NextResponse.json({
    insights: [
      {
        id: "1",
        tag: "SEO",
        category: "Det här funkar",
        severity: "good",
        summary: "Google ger fler besök än förra veckan. Sidan /tjänster/seo driver ökningen.",
        evidence: "Google-besök +22% WoW. /tjänster/seo står för 38% av ökningen. Andel som blev kund/lead +0,4 p.p.",
        actions: [
          "Lägg internlänk till /tjänster/seo från startsidan.",
          "Lägg till 3 frågor & svar längst ner på sidan.",
          "Publicera ett kort kundcase och länka dit.",
        ]
      },
      {
        id: "2",
        tag: "UX",
        category: "Det här funkar inte",
        severity: "bad",
        summary: "Prissidan tappar fler än tidigare. Många lämnar sidan tidigt, särskilt i mobil.",
        evidence: "Prissidans avhopp 62% → 79% d/d efter designändring. Mobil värst.",
        actions: [
          "Byt CTA-text till ‘Starta gratis’.",
          "Komprimera hero-bild till <120KB.",
          "Flytta kundomdömen ovanför vikten.",
        ]
      },
      {
        id: "3",
        tag: "Content",
        category: "Det här funkar",
        severity: "good",
        summary: "Bloggposten om kundcase fick många besök och tid på sidan.",
        evidence: "Tid på sidan +18%, delningar +12%.",
        actions: [
          "Länka blogginlägget från startsidan.",
          "Gör en kort video-version och bädda in."
        ]
      },
      {
        id: "4",
        tag: "Paid",
        category: "Det här funkar inte",
        severity: "bad",
        summary: "Betalda klick ökar men konverterar sämre.",
        evidence: "CPC +20% WoW, CR -0,6 p.p.",
        actions: [
          "Pausa breda sökord och satsa på varumärke.",
          "Sätt sitelinks till prissidan och case-sida."
        ]
      }
    ]
  });
}
