import { NextResponse } from "next/server";

export async function GET(){
  const points = Array.from({length: 28}).map((_,i)=>{
    const date = new Date(); date.setDate(date.getDate() - (28 - i));
    return { date: date.toISOString().slice(0,10), value: Math.round(200 + Math.sin(i/3)*40 + (i*2)) };
  });
  return NextResponse.json({ points });
}
