import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest){
  const { question } = await req.json();
  // Mockat svar
  const answer = "Google/organic gav flest leads (24 st, +18% WoW). Prioritera /tjänster/seo.";
  return NextResponse.json({
    answer,
    evidence: [{ metric: "leads", value: 24, delta: 0.18 }],
    question
  });
}
