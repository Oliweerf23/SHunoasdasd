import { NextResponse } from "next/server";

export async function GET(){
  return NextResponse.json({
    items: [
      { key: "visits", label: "Besök (7 dagar)", value: 7420, delta: 0.12 },
      { key: "people", label: "Personer (7 dagar)", value: 5980, delta: 0.08 },
      { key: "cr", label: "Andel som blev kund/lead", value: 0.024, delta: -0.003 },
      { key: "leads", label: "Leads/Orders (7 dagar)", value: 62, delta: 0.09 }
    ]
  });
}
